# EPIC-001: Core Infrastructure Setup

## Epic Description
Establish foundational AWS infrastructure for UKHSA data sharing platform

## User Stories

### STORY-001: S3 Bucket Configuration
**As a** Data Engineer  
**I want** properly configured S3 buckets with appropriate policies  
**So that** data can be securely uploaded, processed, and downloaded

**Acceptance Criteria:**
- [ ] Upload bucket with SSO/MFA access controls
- [ ] Landing bucket for Macie scanning
- [ ] Download bucket for validated data
- [ ] Log bucket for audit trails
- [ ] Lifecycle policies for cost optimization
- [ ] Versioning enabled for data protection

**Technical Requirements:**
- Bucket naming convention: `ukhsa-{environment}-{purpose}-{region}`
- Server-side encryption with KMS
- Cross-region replication for disaster recovery
- CloudTrail logging enabled

**Dependencies:** IAM roles and policies
**Effort:** 5 story points

### STORY-002: IAM Roles and Policies
**As a** Security Administrator  
**I want** role-based access controls implemented  
**So that** users have appropriate permissions based on their responsibilities

**Acceptance Criteria:**
- [ ] UKHSA staff role with upload/download permissions
- [ ] DA staff role with download-only permissions
- [ ] Data Engineer role with full platform access
- [ ] Service roles for Lambda and Glue
- [ ] SSO integration configured
- [ ] MFA enforcement enabled

**Technical Requirements:**
- Principle of least privilege
- Cross-account access for DAs
- Session duration limits
- Resource-based policies for S3 buckets

**Dependencies:** None
**Effort:** 8 story points

### STORY-003: AWS Macie Configuration
**As a** Compliance Officer  
**I want** automated PII detection on uploaded files  
**So that** sensitive data is identified and handled appropriately

**Acceptance Criteria:**
- [ ] Macie enabled for upload bucket
- [ ] Custom data identifiers for health data
- [ ] Automated findings classification
- [ ] Integration with CloudWatch for alerting
- [ ] Quarantine process for PII-containing files

**Technical Requirements:**
- Macie job scheduling for new uploads
- Custom regex patterns for health identifiers
- SNS topic for findings notifications
- Lambda function for file quarantine

**Dependencies:** S3 buckets, IAM roles
**Effort:** 13 story points
