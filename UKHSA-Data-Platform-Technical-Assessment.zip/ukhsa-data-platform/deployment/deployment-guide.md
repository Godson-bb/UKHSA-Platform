# Deployment Guide

## Prerequisites
- AWS CLI configured with appropriate permissions
- CloudFormation deployment rights
- Access to target AWS account

## Deployment Steps

### 1. Infrastructure Deployment
```bash
# Deploy core infrastructure
aws cloudformation deploy \
  --template-file infrastructure/cloudformation-template.yaml \
  --stack-name ukhsa-data-platform-dev \
  --parameter-overrides Environment=dev \
  --capabilities CAPABILITY_NAMED_IAM

# Verify deployment
aws cloudformation describe-stacks \
  --stack-name ukhsa-data-platform-dev
```

### 2. Lambda Function Deployment
```bash
# Package Lambda function
cd src/
zip -r validation-function.zip validation_handler.py

# Update Lambda function
aws lambda update-function-code \
  --function-name ukhsa-data-platform-dev-validation \
  --zip-file fileb://validation-function.zip
```

### 3. Configuration Steps
- Configure Macie for PII detection
- Set up SES for email notifications
- Configure Glue crawlers and jobs
- Set up Athena workgroups

### 4. Testing
- Upload test files to validate pipeline
- Verify email notifications
- Check CloudWatch logs
- Test Athena queries

## Rollback Procedure
```bash
# Rollback CloudFormation stack
aws cloudformation cancel-update-stack \
  --stack-name ukhsa-data-platform-dev

# Or delete stack entirely
aws cloudformation delete-stack \
  --stack-name ukhsa-data-platform-dev
```
