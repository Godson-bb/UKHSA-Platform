import json
import boto3
import pandas as pd
from typing import Dict, List, Any

class DataValidator:
    def __init__(self):
        self.s3_client = boto3.client('s3')
        self.ses_client = boto3.client('ses')
        
    def validate_file(self, bucket: str, key: str) -> Dict[str, Any]:
        """Main validation orchestrator"""
        try:
            # Download and parse file
            file_content = self._download_file(bucket, key)
            
            # Determine file type and validate
            if key.endswith('.csv'):
                df = pd.read_csv(file_content)
            elif key.endswith('.xlsx'):
                df = pd.read_excel(file_content)
            else:
                return self._create_error_response("Unsupported file format")
            
            # Run validation checks
            validation_results = self._run_validations(df, key)
            
            if validation_results['is_valid']:
                self._move_to_processed(bucket, key)
                return self._create_success_response(validation_results)
            else:
                self._quarantine_file(bucket, key)
                self._send_error_notification(key, validation_results['errors'])
                return self._create_error_response(validation_results['errors'])
                
        except Exception as e:
            return self._create_error_response(f"Processing error: {str(e)}")
    
    def _run_validations(self, df: pd.DataFrame, filename: str) -> Dict[str, Any]:
        """Execute all validation rules"""
        errors = []
        
        # Schema validation
        required_columns = ['date', 'region', 'disease', 'count']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            errors.append(f"Missing required columns: {missing_columns}")
        
        # Data quality checks
        if df.empty:
            errors.append("File contains no data rows")
        
        if 'count' in df.columns and df['count'].isnull().any():
            errors.append("Count column contains null values")
        
        # Business rules
        if 'count' in df.columns and (df['count'] < 0).any():
            errors.append("Count values cannot be negative")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'row_count': len(df),
            'filename': filename
        }

def lambda_handler(event, context):
    """AWS Lambda entry point"""
    validator = DataValidator()
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        result = validator.validate_file(bucket, key)
        print(f"Validation result for {key}: {result}")
    
    return {'statusCode': 200}
