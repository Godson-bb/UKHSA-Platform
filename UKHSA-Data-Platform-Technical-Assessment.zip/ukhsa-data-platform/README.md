# UKHSA Data Sharing Platform

## Project Overview
Data sharing platform between UKHSA and Devolved Administrations for non-PII communicable disease data.

## Architecture Components
- **Ingestion**: S3 Landing Bucket (XML/CSV/XLS)
- **Security**: AWS Macie PII scanning, SSO/MFA
- **Processing**: Glue ETL jobs, Lambda validation
- **Analytics**: Athena queries, Power BI dashboards
- **Monitoring**: CloudWatch, SES notifications

## Repository Structure
```
├── docs/                 # Architecture and design documentation
├── infrastructure/       # IaC templates (CloudFormation/Terraform)
├── src/                 # Lambda functions and validation code
├── tests/               # Unit and integration tests
├── deployment/          # CI/CD and deployment scripts
└── tickets/             # Engineering tickets and user stories
```

## Development Timeline
Target delivery: Q4 2025
